import { Component } from "react";

class OurCoffeeItem extends Component {
    render() {
        return (
            <div className="page-our-coffee-item">
                <h1>OurCoffeeItem Page</h1>
            </div>
        );
    }
}

export default OurCoffeeItem;
