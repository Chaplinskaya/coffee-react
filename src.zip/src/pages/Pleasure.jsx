import { Component } from "react";

class Pleasure extends Component {
    render() {
        return (
            <div className="page-pleasure">
                <h1>Pleasure Page</h1>
            </div>
        );
    }
}

export default Pleasure;
