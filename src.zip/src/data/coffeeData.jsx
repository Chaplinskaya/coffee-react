import solimo from "../img/solimo.png";
import aromito from "../img/aromito.png";
import presto from "../img/presto.png";

export const coffeeData = [
    { id: 1, title: "Solimo Coffee Beans 2 kg", country: "Brazil", price: 10.73, image: solimo },
    { id: 2, title: "Presto Coffee Beans 1 kg", country: "Colombia", price: 15.99, image: aromito },
    { id: 3, title: "AROMISTICO Coffee 1 kg", country: "Kenya", price: 6.99, image: presto }
]